angular.module('iwuApp.controllers', [])














    .controller('AppCtrl', function ($scope) {

    })

    .controller('LoginCtrl', function ($scope){

    })

    .controller('MainCtrl', function ($scope, $sce, weatherData) {
        // Title
        $scope.navTitle = 'IWU';

        /* Json */
        // Today's Weather
        var todaysWeatherObject = weatherData.todaysWeather();
        console.log(JSON.stringify(todaysWeatherObject));
        $scope.city = todaysWeatherObject.city;
        /*$scope.tempMin = tempMin;
        $scope.tempMax = tempMax;*/


        // Current Weather
        /*$scope.temp = temp;
        $scope.icon = $sce.trustAsHtml(icon);*/

        // Date
        /*$scope.dayMonth = dayMonth;
        $scope.dayWeek = dayWeekOutput;
        $scope.monthYear = monthYearOutput;*/
    })

    .controller('NewsCtrl', function ($scope){
        $scope.navTitle = 'News';
    })

    .controller('ChapelCtrl', function ($scope){
        $scope.navTitle = 'Chapel';
    })

    .controller('ScheduleCtrl', function ($scope){
        $scope.navTitle = 'Schedule';
    })

    .controller('BaldwinCtrl', function ($scope){
        $scope.navTitle = 'Baldwin';
    })

    .controller('SettingsCtrl', function ($scope){
        $scope.navTitle = 'Settings';
    });