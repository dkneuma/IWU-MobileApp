angular.module('iwuApp.controllers', [])

    .controller('AppCtrl', function ($scope) {

    })

    .controller('LoginCtrl', function ($scope){

    })

    .controller('MainCtrl', function ($scope, $http, $sce) {
        /* Title */
        $scope.navTitle = '<span>IWU</span>';

        /* Json */

        // Today's Weather
        $http.get('http://api.openweathermap.org/data/2.5/forecast/daily?id=4923210&mode=json&units=imperial&cnt=1&APPID=82459d090e8552ff5ef308f72a1a5642')
            .success(function(data){
                var jsonObj = data;

                var city = jsonObj.city.name;
                var tempMin = jsonObj.list[0].temp.min;
                var tempMax = jsonObj.list[0].temp.max;

                $scope.city = city;
                $scope.tempMin = Math.round(tempMin);
                $scope.tempMax = Math.round(tempMax);
            })
            .error(function(){
                console.log('Todays not working');
            });


        // Current Weather
        $http.get('http://api.openweathermap.org/data/2.5/weather?id=4923210&units=imperial&mode=json&APPID=82459d090e8552ff5ef308f72a1a5642')
            .success(function(data){
                var jsonObj = data;

                var temp = jsonObj.main.temp;
                var icon = jsonObj.weather[0].icon;
                var iconCodes = [];
                    iconCodes[0] = '01d';
                    iconCodes[1] = '01n';
                    iconCodes[2] = '02d';
                    iconCodes[3] = '02n';
                    iconCodes[4] = '03d';
                    iconCodes[5] = '03n';
                    iconCodes[6] = '04d';
                    iconCodes[7] = '04n';
                    iconCodes[8] = '09d';
                    iconCodes[9] = '09n';
                    iconCodes[10] = '10d';
                    iconCodes[11] = '10n';
                    iconCodes[12] = '11d';
                    iconCodes[13] = '11n';
                    iconCodes[14] = '13d';
                    iconCodes[15] = '13n';
                    iconCodes[16] = '50d';
                    iconCodes[17] = '50n';
                var iconCodesPosition = iconCodes.indexOf(icon);
                var climacons = [];
                    climacons[0] = 'climacon sun';
                    climacons[1] = 'climacon moon waxing crescent';
                    climacons[2] = 'climacon cloud sun';
                    climacons[3] = 'climacon cloud moon';
                    climacons[4] = 'climacon cloud';
                    climacons[5] = 'climacon cloud';
                    climacons[6] = 'climacon cloud';
                    climacons[7] = 'climacon cloud';
                    climacons[8] = 'climacon showers sun';
                    climacons[9] = 'climacon showers moon';
                    climacons[10] = 'climacon downpour sun';
                    climacons[11] = 'climacon downpour moon';
                    climacons[12] = 'climacon lightning sun';
                    climacons[13] = 'climacon lightning moon';
                    climacons[14] = 'climacon snow sun';
                    climacons[15] = 'climacon snow moon';
                    climacons[16] = 'climacon fog';
                    climacons[17] = 'climacon fog';
                    climacons[18] = 'climacon sunglasses';

                if(iconCodesPosition == -1){
                    icon = climacons[18];
                }
                else{
                    icon = climacons[iconCodesPosition];
                }

                $scope.temp = Math.round(temp);
                $scope.icon = $sce.trustAsHtml(icon);
            })
            .error(function(){
                console.log('Current weather not working');
            });

        /* Date */
        var date = new Date();
        var dayMonth = date.getDate();
        var dayWeek = [];
            dayWeek[0] = 'sun';
            dayWeek[1] = 'mon';
            dayWeek[2] = 'tue';
            dayWeek[3] = 'wed';
            dayWeek[4] = 'thu';
            dayWeek[5] = 'fri';
            dayWeek[6] = 'sat';
        var monthYear = [];
            monthYear[0] = 'jan';
            monthYear[1] = 'feb';
            monthYear[2] = 'mar';
            monthYear[3] = 'apr';
            monthYear[4] = 'may';
            monthYear[5] = 'jun';
            monthYear[6] = 'jul';
            monthYear[7] = 'aug';
            monthYear[8] = 'sep';
            monthYear[9] = 'oct';
            monthYear[10] = 'nov';
            monthYear[11] = 'dec';

        $scope.dayMonth = dayMonth;
        $scope.dayWeek = dayWeek[date.getDay()];
        $scope.monthYear = monthYear[date.getMonth()];
    })

    .controller('NewsCtrl', function ($scope){
        $scope.navTitle = 'News';
    })

    .controller('ChapelCtrl', function ($scope){
        $scope.navTitle = 'Chapel';
    })

    .controller('ScheduleCtrl', function ($scope){
        $scope.navTitle = 'Schedule';
    })

    .controller('BaldwinCtrl', function ($scope){
        $scope.navTitle = 'Baldwin';
    })

    .controller('SettingsCtrl', function ($scope){
        $scope.navTitle = 'Settings';
    });